/*
 ============================================================================
 Name        : Ingreso.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {

	char respuesta = 's';
	int promedioNumeros;
	int acumuladorNumeros = 0;
	int numeroIngresado;
	int numeroMaximo;
	int numeroMinimo;
	int contadorNumeros = 0;
	int flag = 0;

	while(respuesta == 's'){
		printf("Ingrese un número.\n");
		scanf("%d",&numeroIngresado);

		if(flag == 0){
			flag = 1;
			numeroMaximo = numeroIngresado;
			numeroMinimo = numeroIngresado;
		}
		else{
			if(numeroIngresado > numeroMaximo){
				numeroMaximo = numeroIngresado;
			}
			if(numeroIngresado < numeroMinimo){
				numeroMinimo = numeroIngresado;
			}
		}
		acumuladorNumeros = acumuladorNumeros + numeroIngresado;
		contadorNumeros = contadorNumeros +1;
		printf("Desea ingresar otro valor? \n");
		scanf("%s",&respuesta);
	}
	promedioNumeros = acumuladorNumeros / contadorNumeros;
	printf("El número máximo es: %d \n",numeroMaximo);
	printf("El número mínimo es: %d \n",numeroMinimo);
	printf("El total de números ingresados es de: %d \n",contadorNumeros);
	printf("El promedio de todos los números ingresados es: %d",promedioNumeros);


}


/* usuario ingrese numeros indefinidamente
 * informar maximo, minimo y cuantos numeros ingreso
 */
